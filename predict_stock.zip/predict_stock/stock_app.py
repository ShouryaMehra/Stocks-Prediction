from flask import *
from flask import Flask, render_template, request
from joblib import load
import logging





# initialize logging 
LOG_FILE_NAME= 'loanApplog.txt'
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s''',
                    datefmt='%m-%d %H:%M',
                    filename=LOG_FILE_NAME,
                    filemode='w')




app = Flask(__name__) #create instence of web server

appstock = load('C:/Users/Shourya/predict_stock/real_data.joblib')

@app.route('/',methods=['POST', 'GET'])
def index():
    return render_template('index.html')
            
@app.route('/prd',methods=['POST','GET'])

def stock_ped():

    
    Hang_Seng_AdjClose  = 0.0
    Hang_Seng_Open = 0.0
    NASDAQ_AdjClose = 0.0
    NASDAQ_Open = 0.0
    Nikkei_225_AdjClose = 0.0
    Nikkei_225_Open = 0.0
    NIFTY_50_AdjClose = 0.0
    NIFTY_50_Open = 0.0
    es_train_AdjClose = 0.0
    
    es_train_Open = 0.0
    
    if request.method == 'POST':
        try:
            Hang_Seng_AdjClose =float(request.form['Hang_Seng_AdjClose'])
            Hang_Seng_Open = float(request.form['Hang_Seng_Open'])
            NASDAQ_AdjClose = float(request.form['NASDAQ_AdjClose'])
            NASDAQ_Open = float(request.form['NASDAQ_Open']) 
            Nikkei_225_AdjClose =float(request.form['Nikkei_225_AdjClose'])
            Nikkei_225_Open = float(request.form['Nikkei_225_Open'])
            NIFTY_50_AdjClose = float(request.form['NIFTY_50_AdjClose'])
            NIFTY_50_Open = float(request.form['NIFTY_50_Open']) 
            es_train_AdjClose = float(request.form['es_train_AdjClose']) 
            
 
            
            
            es_train_Open = appstock.predict([[Hang_Seng_AdjClose,Hang_Seng_Open,NASDAQ_AdjClose,
                                           NASDAQ_Open,Nikkei_225_AdjClose,Nikkei_225_Open,
                                           NIFTY_50_AdjClose,NIFTY_50_Open,es_train_AdjClose]])
            
            

                            
        except:  
            es_train_Open = 'Error!'
            logging.exception(es_train_Open)
                              
            
    return render_template('stock_frame.html',es_train_Open=es_train_Open)  




    
if __name__ == '__main__': #this only page run as a main page if it not run as a main page web server will not work,
    app.run()